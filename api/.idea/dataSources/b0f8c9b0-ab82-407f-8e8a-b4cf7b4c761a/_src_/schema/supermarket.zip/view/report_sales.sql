CREATE VIEW report_sales AS
  SELECT
    `co`.`order_date`       AS `order_date`,
    sum(`co`.`order_total`) AS `sales`
  FROM `supermarket`.`customer_order` `co`
  WHERE (`co`.`order_date` IS NOT NULL)
  GROUP BY `co`.`order_date` DESC;
