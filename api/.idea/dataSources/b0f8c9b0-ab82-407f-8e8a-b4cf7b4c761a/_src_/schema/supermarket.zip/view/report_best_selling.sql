CREATE VIEW report_best_selling AS
  SELECT
    `supermarket`.`product`.`prod_name`          AS `product`,
    sum(`supermarket`.`order_item`.`item_total`) AS `sales`
  FROM (`supermarket`.`order_item`
    JOIN `supermarket`.`product` ON ((`supermarket`.`order_item`.`product` = `supermarket`.`product`.`prod_id`)))
  GROUP BY `supermarket`.`order_item`.`product`
  ORDER BY sum(`supermarket`.`order_item`.`item_total`) DESC
  LIMIT 5;
